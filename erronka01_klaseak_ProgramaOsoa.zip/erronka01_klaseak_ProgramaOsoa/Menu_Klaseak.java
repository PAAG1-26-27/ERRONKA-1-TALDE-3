/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.erronka01_klaseak_ProgramaOsoa;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Aguirresarobe.Imanol
 */
public class Menu_Klaseak 
{
    Scanner sc = new Scanner(System.in);
    
    public void gehituLang(ArrayList<Langilea> LL)
    {
        LL.add(new Langilea());
        LL.get(LL.size()-1).setNAN();
        LL.get(LL.size()-1).setIzena();
        LL.get(LL.size()-1).setAbizena();
        LL.get(LL.size()-1).setJaiotze_data();
        LL.get(LL.size()-1).setTelefonoa();
        LL.get(LL.size()-1).setLangile_Id();
        LL.get(LL.size()-1).setDepartamentua();
    }
    public void kenduLang(ArrayList<Langilea> LL)
    {
        String t;
        int i;
        System.out.println("Zein langile kendu nahi duzu? Sartu langilearen kodea");
        sc.nextLine();
        t=sc.nextLine();
        for(i=0;i<LL.size();i++)
        {
            if(LL.get(i).getLangile_Id().equals(t))
            {
                LL.remove(i);
            }    
        }

    }
    public void aldatuLang(ArrayList<Langilea> LL)
    {
        String t;
        int i,l=-1, d;
        System.out.println("Zein langileri Aldatu nahi duzu daturen bat? Sartu langilearen kodea");
        sc.nextLine();
        t=sc.nextLine();
        for(i=0;i<LL.size();i++)
        {
            if(LL.get(i).getLangile_Id().equals(t))
            {
                l=i;
            }    
        }
        System.out.println("Ze datu aldatu nahi duzu?");
        System.out.println("1. NAN");
        System.out.println("2. Izena");
        System.out.println("3. Abizena");
        System.out.println("4. Jaiotze data");
        System.out.println("5. Telefonoa");
        System.out.println("6. Langile ID-a");
        System.out.println("7. Departamentua");
        d=sc.nextInt();
        switch(d)
        {
            case 1:
            {
                LL.get(l).setNAN();
            }
            break;
            case 2:
            {
                LL.get(l).setIzena();
            }
            break;
            case 3:
            {
                LL.get(l).setAbizena();
            }
            break;
            case 4:
            {
                LL.get(l).setJaiotze_data();
            }
            break;
            case 5:
            {
                LL.get(l).setTelefonoa();
            }
            break;
            case 6:
            {
                LL.get(l).setLangile_Id();
            }
            break;
            case 7:
            {
                LL.get(l).setDepartamentua();
            }
            break;
        }
    }
    public void bistaratuLang(ArrayList<Langilea> LL)
    {
        int i;
        for(i=0;i<LL.size();i++)
        {
            LL.get(i).getAllLangilea();
            System.out.println("\n");
        }
    }
    
    public void gehituBeze(ArrayList<Bezeroa> BL)
    {
        int aukera;
        BL.add(new Bezeroa());
        BL.get(BL.size()-1).setNAN();
        BL.get(BL.size()-1).setIzena();
        BL.get(BL.size()-1).setAbizena();
        BL.get(BL.size()-1).setJaiotze_data();
        BL.get(BL.size()-1).setTelefonoa();
        System.out.println("Bezero hau bazkidea da? 1.Bai 2.Ez");
        aukera=sc.nextInt();
        if (aukera==1)
        {
            BL.get(BL.size()-1).setBazk_kodea();
        }
        else
        {
            BL.get(BL.size()-1).setBazk_kodea("Ez");
        }
        BL.get(BL.size()-1).setNazionalitatea();
    }
    public void kenduBeze(ArrayList<Bezeroa> BL)
    {
        String t;
        int i, aukera;
        System.out.println("Bezero hau bazkidea da? 1.Bai 2.Ez");
        aukera=sc.nextInt();
        do
        {
            if (aukera==1)
            {
                System.out.println("Zein Bazkide kendu nahi duzu? Sartu Bazkide kodea");
                sc.nextLine();
                t=sc.nextLine();
                for(i=0;i<BL.size();i++)
                {
                    if(BL.get(i).getBazk_kodea().equals(t))
                    {
                        BL.remove(i);
                    }    
                }
            }
            if (aukera==2)
            {
                System.out.println("Zein Bezero kendu nahi duzu? Sartu Bezeroaren NAN-a");
                sc.nextLine();
                t=sc.nextLine();
                for(i=0;i<BL.size();i++)
                {
                    if(BL.get(i).getNAN().equals(t))
                    {
                        BL.remove(i);
                    }    
                }

            }
            if(aukera<1 || aukera>2)
            {
                System.out.println("Mesedez erantzun balido bat sartu");
            }
        }
        while(aukera<1 || aukera>2);
    }
    public void aldatuBeze(ArrayList<Bezeroa> BL)
    {
        String t;
        int i,l=-1, d;
        System.out.println("Zein Bezerori Aldatu nahi duzu daturen bat? Sartu bezeroaren NAN-a");
        sc.nextLine();
        t=sc.nextLine();
        for(i=0;i<BL.size();i++)
        {
            if(BL.get(i).getNAN().equals(t))
            {
                l=i;
            }    
        }
        System.out.println("Ze datu aldatu nahi duzu?");
        System.out.println("1. NAN");
        System.out.println("2. Izena");
        System.out.println("3. Abizena");
        System.out.println("4. Jaiotze data");
        System.out.println("5. Telefonoa");
        System.out.println("6. Bazkide kodea");
        System.out.println("7. Nazionalitatea");
        d=sc.nextInt();
        switch(d)
        {
            case 1:
            {
                BL.get(l).setNAN();
            }
            break;
            case 2:
            {
                BL.get(l).setIzena();
            }
            break;
            case 3:
            {
                BL.get(l).setAbizena();
            }
            break;
            case 4:
            {
                BL.get(l).setJaiotze_data();
            }
            break;
            case 5:
            {
                BL.get(l).setTelefonoa();
            }
            break;
            case 6:
            {
                BL.get(l).setBazk_kodea();
            }
            break;
            case 7:
            {
                BL.get(l).setNazionalitatea();
            }
            break;
        }
    }
    public void bistaratuBeze(ArrayList<Bezeroa> BL)
    {
        int i;
        for(i=0;i<BL.size();i++)
        {
            BL.get(i).getAllBez();
            System.out.println("\n");
        }
    }
    
    public void gehituEkin(ArrayList<Ekintza> EL, ArrayList<Lo_Egitekoa> LeL)
    {
        int aukera;
        EL.add(new Ekintza());
        EL.get(EL.size()-1).setEkintza_id();
        EL.get(EL.size()-1).setLekua();
        EL.get(EL.size()-1).setIzaera();
        EL.get(EL.size()-1).setEkintza_data();
        EL.get(EL.size()-1).setPrezioa();
        EL.get(EL.size()-1).setMota();
        if ("Udakoa".equalsIgnoreCase(EL.get(EL.size()-1).getMota()))
        {
            do
            {
                System.out.println("Zer udako ekintza mota da? 1. Egunezkoa 2. Lo egitekoa");
                aukera=sc.nextInt();
            }
            while (aukera<1 || aukera>2);
            if(aukera==1)
            {
                EL.get(EL.size()-1).setMota("Egunezkoa");
            }
            if(aukera==2)
            {
                EL.get(EL.size()-1).setMota("Lo egitekoa");
            }
        }
        
        if ("Lo egitekoa".equals(EL.get(EL.size()-1).getMota()))
        {
            LeL.add(new Lo_Egitekoa());
            LeL.get(LeL.size()-1).setEkintza_id(EL.get(EL.size()-1).getEkintza_id());
            LeL.get(LeL.size()-1).setLekua(EL.get(EL.size()-1).getLekua());
            LeL.get(LeL.size()-1).setIzaera(EL.get(EL.size()-1).getIzaera());
            LeL.get(LeL.size()-1).setEkintza_data(EL.get(EL.size()-1).getEkintza_data());
            LeL.get(LeL.size()-1).setPrezioa(EL.get(EL.size()-1).getPrezioa());              
            LeL.get(LeL.size()-1).setMota(EL.get(EL.size()-1).getMota());              
            LeL.get(LeL.size()-1).setUdaleku_izena();
            LeL.get(LeL.size()-1).setEgun_kop();
            
        }

    }
    public void kenduEkin(ArrayList<Ekintza> EL, ArrayList<Lo_Egitekoa> LeL)
    {
        String t;
        int i;
        System.out.println("Zein Ekintza kendu nahi duzu? Sartu Ekintza ID-a");
        sc.nextLine();
        t=sc.nextLine();
        for(i=0;i<EL.size();i++)
        {
            if(EL.get(i).getEkintza_id().equals(t))
            {
                EL.remove(i);
            } 
            if(!LeL.isEmpty())
            {
                if(LeL.get(i).getEkintza_id().equals(t))
                {
                    LeL.remove(i);
                } 
            }    
        }    
    }
    public void aldatuEkin(ArrayList<Ekintza> EL, ArrayList<Lo_Egitekoa> LeL)
    {
        String t, id_temp;
        int i,j,l=-1, d,w=0;
        System.out.println("Zein Ekintzari aldatu nahi duzu daturen bat? Sartu ekintzaren ID-a");
        sc.nextLine();
        t=sc.nextLine();
        for(i=0;i<EL.size();i++)
        {
            if(EL.get(i).getEkintza_id().equals(t))
            {
                l=i;
            }    
        }
        System.out.println("Ze datu aldatu nahi duzu?");
        System.out.println("1. Ekintza Id");
        System.out.println("2. Lekua");
        System.out.println("3. Izaera");
        System.out.println("4. Ekintza data");
        System.out.println("5. Prezioa");
        System.out.println("6. Mota");
        if("Lo egitekoa".equalsIgnoreCase(EL.get(l).getMota()))
            {
                System.out.println("7. Egun kopuruak");
            }
        if("Lo egitekoa".equalsIgnoreCase(EL.get(l).getMota()))
            {
                System.out.println("8. Udalekuaren izena");
            }
        d=sc.nextInt();
        switch(d)
        {
            case 1:
            {
                System.out.println("Sartu ekintzaren ID-a");
                sc.nextLine();
                id_temp=sc.nextLine();
                if("Lo egitekoa".equalsIgnoreCase(EL.get(l).getMota()))
                {
                    for(j=0;j<LeL.size();j++)
                    {
                        if(EL.get(l).getEkintza_id().equals(LeL.get(j).getEkintza_id()))
                        {
                            w=j;
                        }
                    }
                    LeL.get(w).setEkintza_id(id_temp);
                }
                EL.get(l).setEkintza_id(id_temp);
            }
            break;
            case 2:
            {
                EL.get(l).setLekua();
                if("Lo egitekoa".equalsIgnoreCase(EL.get(l).getMota()))
                {
                    for(j=0;j<LeL.size();j++)
                    {
                        if(EL.get(l).getEkintza_id().equals(LeL.get(j).getEkintza_id()))
                        {
                            w=j;
                        }
                    }
                    LeL.get(w).setLekua(EL.get(l).getLekua());
                }
            }
            break;
            case 3:
            {
                EL.get(l).setIzaera();
                if("Lo egitekoa".equalsIgnoreCase(EL.get(l).getMota()))
                {
                    for(j=0;j<LeL.size();j++)
                    {
                        if(EL.get(l).getEkintza_id().equals(LeL.get(j).getEkintza_id()))
                        {
                            w=j;
                        }
                    }
                    LeL.get(w).setIzaera(EL.get(l).getIzaera());
                }
            }
            break;
            case 4:
            {
                EL.get(l).setEkintza_data();
                if("Lo egitekoa".equalsIgnoreCase(EL.get(l).getMota()))
                {
                    for(j=0;j<LeL.size();j++)
                    {
                        if(EL.get(l).getEkintza_id().equals(LeL.get(j).getEkintza_id()))
                        {
                            w=j;
                        }
                    }
                    LeL.get(w).setEkintza_data(EL.get(l).getEkintza_data());
                }
            }
            break;
            case 5:
            {
                EL.get(l).setPrezioa();
                if("Lo egitekoa".equalsIgnoreCase(EL.get(l).getMota()))
                {
                    for(j=0;j<LeL.size();j++)
                    {
                        if(EL.get(l).getEkintza_id().equals(LeL.get(j).getEkintza_id()))
                        {
                            w=j;
                        }
                    }
                    LeL.get(w).setPrezioa(EL.get(l).getPrezioa());
                }
            }
            break;
            case 6:
            {
                EL.get(l).setMota();
                if("Lo egitekoa".equalsIgnoreCase(EL.get(l).getMota()))
                {
                    for(j=0;j<LeL.size();j++)
                    {
                        if(EL.get(l).getEkintza_id().equals(LeL.get(j).getEkintza_id()))
                        {
                            w=j;
                        }
                    }
                    LeL.get(w).setMota(EL.get(l).getMota());
                }
            }
            break;
        }
        if("Lo egitekoa".equalsIgnoreCase(EL.get(l).getMota()))
        {
            switch(d)
            {
                case 7:
                {
                    LeL.get(l).setEgun_kop();
                }
                break;
                case 8:
                {
                    LeL.get(l).setUdaleku_izena();
                }
                break;
            }
        }
    }
    public void bistaratuEkin(ArrayList<Ekintza> EL, ArrayList<Lo_Egitekoa> LeL)
    {
        int i,j=0;
        for(i=0;i<EL.size();i++)
        {
            EL.get(i).getAll_Ekintza();
            if("Lo egitekoa".equals(EL.get(EL.size()-1).getMota()))
            {
                System.out.println("Udalekua: "+LeL.get(j).getUdaleku_izena());
                System.out.println("Egun kopurua: "+LeL.get(j).getEgun_kop());
                j++;
            }
            System.out.println("\n");
        }
    }
    public void bistaratuLo_e(ArrayList<Lo_Egitekoa> LeL)
    {
        int i;
        for(i=0;i<LeL.size();i++)
        {
            LeL.get(i).getAll_Lo_egitekoa();            
            System.out.println("\n");
        }
    }
    
    public void main(String[] args) 
    {
        int menu_aukera, submenu_aukera;
        ArrayList<Langilea>LangList = new ArrayList();
        ArrayList<Bezeroa>BezeList = new ArrayList();
        ArrayList<Ekintza>EkinList = new ArrayList();
        ArrayList<Lo_Egitekoa>Lo_EList = new ArrayList();
        do
        {
            System.out.printf("\n||MENUA||\nZer egin nahi duzu?\n---------------------\n");
            System.out.println("1. Langileak kudeatu.");
            System.out.println("2. Bezeroak kudeatu.");
            System.out.println("3. Ekintzak kudeatu.");
            System.out.println("---------------------\n0. irten. ");
            menu_aukera=sc.nextInt();
            switch(menu_aukera)
            {
                case 1:
                {
                    do
                    {
                        System.out.printf("********************\nZer egin nahi duzu?\n---------------------\n");
                        System.out.println("1. Langile bat gehitu.");
                        System.out.println("2. Langile bat kendu.");
                        System.out.println("3. Langile baten informazioa aldatu.");
                        System.out.println("4. Langileak bistaratu.");
                        System.out.println("---------------------\n0. atzera bueltatu. ");
                        submenu_aukera=sc.nextInt();
                        switch(submenu_aukera)
                        {
                            case 1:
                            {
                                gehituLang(LangList);
                            }
                            break;
                            case 2:
                            {
                                if(LangList.isEmpty())
                                {
                                    System.out.println("Ez dago langilerikk ezabatzeko");
                                }
                                else
                                {
                                    kenduLang(LangList);
                                }
                            }
                            break;
                            case 3:
                            {
                                if(LangList.isEmpty())
                                {
                                    System.out.println("Ez dago langilerikk aldatzeko");
                                }
                                else
                                {
                                    aldatuLang(LangList);
                                }
                            }
                            break;
                            case 4:
                            {
                                if(LangList.isEmpty())
                                {
                                    System.out.println("Ez dago langilerik bistaratzeko");
                                }
                                else
                                {
                                    bistaratuLang(LangList);
                                }
                            }
                            break;
                        }                    
                    }
                    while(submenu_aukera!=0);
                }
                break;
                case 2:
                {
                    do
                    {
                        System.out.printf("********************\nZer egin nahi duzu?\n---------------------\n");
                        System.out.println("1. Bezero bat gehitu.");
                        System.out.println("2. Bezero bat kendu.");
                        System.out.println("3. Bezero baten informazioa aldatu.");
                        System.out.println("4. Bezeroak bistaratu.");
                        System.out.println("---------------------\n0. atzera bueltatu. ");
                        submenu_aukera=sc.nextInt();
                        switch(submenu_aukera)
                        {
                           case 1:
                            {
                                gehituBeze(BezeList);
                            }
                            break;
                            case 2:
                            {
                                if(BezeList.isEmpty())
                                {
                                    System.out.println("Ez dago bezerorik ezabatzeko");
                                }
                                else
                                {
                                    kenduBeze(BezeList);
                                }
                            }
                            break;
                            case 3:
                            {
                                if(BezeList.isEmpty())
                                {
                                    System.out.println("Ez dago bezerorik aldatzeko");
                                }
                                else
                                {
                                    aldatuBeze(BezeList);
                                }
                            }
                            break;
                            case 4:
                            {
                                if(BezeList.isEmpty())
                                {
                                    System.out.println("Ez dago bezerorik bistaratzeko");
                                }
                                else
                                {
                                    bistaratuBeze(BezeList);
                                }
                            }
                            break;
                        }                    
                    }
                    while(submenu_aukera!=0);
                }
                break;
                case 3:
                {
                    do
                    {
                        System.out.printf("********************\nZer egin nahi duzu?\n---------------------\n");
                        System.out.println("1. Ekintza bat gehitu.");
                        System.out.println("2. Ekintza bat kendu.");
                        System.out.println("3. Ekintza baten informazioa aldatu.");
                        System.out.println("4. Ekintzak bistaratu.");
                        System.out.println("5. Lo egiteko ekintzak bistaratu zehazki.");
                        System.out.println("---------------------\n0. atzera bueltatu. ");
                        submenu_aukera=sc.nextInt();
                        switch(submenu_aukera)
                        {
                           case 1:
                            {
                                gehituEkin(EkinList, Lo_EList);
                            }
                            break;
                            case 2:
                            {
                                if(EkinList.isEmpty())
                                {
                                    System.out.println("Ez dago ekintzarik ezabatzeko");
                                }
                                else
                                {
                                    kenduEkin(EkinList, Lo_EList);
                                }
                            }
                            break;
                            case 3:
                            {
                                if(EkinList.isEmpty())
                                {
                                    System.out.println("Ez dago Ekintzarik aldatzeko");
                                }
                                else
                                {
                                    aldatuEkin(EkinList,Lo_EList);
                                }
                            }
                            break;
                            case 4:
                            {
                                if(EkinList.isEmpty())
                                {
                                    System.out.println("Ez dago ekintzarik bistaratzeko");
                                }
                                else
                                {
                                    bistaratuEkin(EkinList,Lo_EList);
                                }
                            }
                            break;
                            case 5:
                            {
                                if(Lo_EList.isEmpty())
                                {
                                    System.out.println("Ez dago ekintzarik bistaratzeko");
                                }
                                else
                                {
                                    bistaratuLo_e(Lo_EList);
                                }
                            }
                            break;
                        }                    
                    }
                    while(submenu_aukera!=0);
                }
                break;
            }
        }
        while(menu_aukera!=0);
    }
}
