/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.erronka01_klaseak_ProgramaOsoa;

import java.time.LocalDate;
import java.util.Scanner;

/**
 *
 * @author amaia
 */
public class Lo_Egitekoa extends Ekintza
{
    private String Egun_kop;
    private String Udaleku_izena;
    
    public Lo_Egitekoa()
    {
        super();
        Egun_kop="1";
        Udaleku_izena="Udalekua";
    }//eraikitzailea
    
    public Lo_Egitekoa(String e, String u, String i, String L, LocalDate d, String iz, String m, double p)
    {
        super(i,L,d,iz,m,p);
        Egun_kop=e;
        Udaleku_izena=u;
    }//eraikitzailea parametroekin
    
    
    public String setUdaleku_izena()
    {
        String u;
        System.out.println("Sartu udalekuren izena: ");
        Scanner sc= new Scanner(System.in);
        u=sc.nextLine();
        Udaleku_izena=u;
        
        return Udaleku_izena;
    }//setudaleku_izena
    
    public String setUdaleku_izena(String u)
    {
        Udaleku_izena=u;
        return Udaleku_izena;
    }//setUdaleku_izena parametroekin
    
    
    public String setEgun_kop()
    {
        String ek;
        System.out.println("Sartu ekintzak iraugo dituen egunen kopurua: ");
        Scanner sc= new Scanner(System.in);
        ek=sc.nextLine();
        Egun_kop=ek;
        
        return Egun_kop;
    }//setEgun_kop
    
    public String setEgun_kop(String ek)
    {
        Egun_kop=ek;
        return Egun_kop;
    }//setEgun_kop parametroekin
    
    
    public String getUdaleku_izena()
    {
        return Udaleku_izena;
    }//getUdaleku_izena
    

    
    public String getEgun_kop()
    {
        return Egun_kop;
    }//getEgun_kop
    
    public void getAll_Lo_egitekoa()
    {
       super.getAll_Ekintza();
       System.out.println("Udalekua: "+getUdaleku_izena());
       System.out.println("Egun kopurua: "+getEgun_kop());
    }//getAll_Lo_egitekoa
}//class
